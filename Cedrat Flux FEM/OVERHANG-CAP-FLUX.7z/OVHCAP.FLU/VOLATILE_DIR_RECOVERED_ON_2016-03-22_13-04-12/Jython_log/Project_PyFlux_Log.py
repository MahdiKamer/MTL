#! Flux2D 12.0
#! Mon Mar 21 01:04:21 IRDT 2016 loadProject('D:/SimulFlux/OVERHANG-ELECTROSTATIC/OVHCAP.FLU')

AidedMesh[1].aidedMeshState=AidedMeshActivated(meshPoint=MeshPointAssigned(type=MeshPointDynamic()),
                                               meshDeviation=MeshDeviationAssignedExcludeIB(type=MeshDeviationExcludeIBRelative(value=0.5)),
                                               meshRelaxation=MeshRelaxation(lineMeshRelaxation=LineMeshRelaxationAssigned(type=LineMeshRelaxationMedium()),
                                                                             faceMeshRelaxation=FaceMeshRelaxationAssigned(type=FaceMeshRelaxationMedium())))


deleteMesh()

MeshPoint['LARGE','MEDIUM','SMALL'].delete()
saveProject()

checkMesh()

meshDomain()

checkGeometry()

result = checkPhysic()

#! Flux2D 12.0
for count in range(1,10):
     RegionLine['WIRE_0'+str(count)].electroStatic2D=ElectroStatic2DLinePerfectConductorImposedPotential(value='0')

for count in range(10,69):
     RegionLine['WIRE_'+str(count)].electroStatic2D=ElectroStatic2DLinePerfectConductorImposedPotential(value='0')

######################################
for count in range(1,69):
     
     if count < 10:
          curwir='WIRE_0'+str(count)
     else:
          curwir='WIRE_'+str(count)
     
          
     if (count-1) < 10:
          prvwir='WIRE_0'+str(count-1)
     else:
          prvwir='WIRE_'+str(count-1)
     
          
          
     if count != 1:
          RegionLine[prvwir].electroStatic2D=ElectroStatic2DLinePerfectConductorImposedPotential(value='0')
     
     RegionLine[curwir].electroStatic2D=ElectroStatic2DLinePerfectConductorImposedPotential(value='1')
     Scenario['SCENARIO_1'].solve(projectName='D:\SimulFlux\OVERHANG-ELECTROSTATIC\OVHCAP.FLU')
     ComputePhysicTransient['ComputePhysic'].storageName='ComputePhysic_'+curwir
     lastInstance = ComputePhysic(name='ComputePhysic_'+curwir,formula=['Charge(L_WIRE_01)                                                               ', 'Charge(L_WIRE_02)                                                               ', 'Charge(L_WIRE_03)                                                               ', 'Charge(L_WIRE_04)                                                               ', 'Charge(L_WIRE_05)                                                               ', 'Charge(L_WIRE_06)                                                               ', 'Charge(L_WIRE_07)                                                               ', 'Charge(L_WIRE_08)                                                               ', 'Charge(L_WIRE_09)                                                               ', 'Charge(L_WIRE_10)                                                               ', 'Charge(L_WIRE_11)                                                               ', 'Charge(L_WIRE_12)                                                               ', 'Charge(L_WIRE_13)                                                               ', 'Charge(L_WIRE_14)                                                               ', 'Charge(L_WIRE_15)                                                               ', 'Charge(L_WIRE_16)                                                               ', 'Charge(L_WIRE_17)                                                               ', 'Charge(L_WIRE_18)                                                               ', 'Charge(L_WIRE_19)                                                               ', 'Charge(L_WIRE_20)                                                               ', 'Charge(L_WIRE_21)                                                               ', 'Charge(L_WIRE_22)                                                               ', 'Charge(L_WIRE_23)                                                               ', 'Charge(L_WIRE_24)                                                               ', 'Charge(L_WIRE_25)                                                               ', 'Charge(L_WIRE_26)                                                               ', 'Charge(L_WIRE_27)                                                               ', 'Charge(L_WIRE_28)                                                               ', 'Charge(L_WIRE_29)                                                               ', 'Charge(L_WIRE_30)                                                               ', 'Charge(L_WIRE_31)                                                               ', 'Charge(L_WIRE_32)                                                               ', 'Charge(L_WIRE_33)                                                               ', 'Charge(L_WIRE_34)                                                               ', 'Charge(L_WIRE_35)                                                               ', 'Charge(L_WIRE_36)                                                               ', 'Charge(L_WIRE_37)                                                               ', 'Charge(L_WIRE_38)                                                               ', 'Charge(L_WIRE_39)                                                               ', 'Charge(L_WIRE_40)                                                               ', 'Charge(L_WIRE_41)                                                               ', 'Charge(L_WIRE_42)                                                               ', 'Charge(L_WIRE_43)                                                               ', 'Charge(L_WIRE_44)                                                               ', 'Charge(L_WIRE_45)                                                               ', 'Charge(L_WIRE_46)                                                               ', 'Charge(L_WIRE_47)                                                               ', 'Charge(L_WIRE_48)                                                               ', 'Charge(L_WIRE_49)                                                               ', 'Charge(L_WIRE_50)                                                               ', 'Charge(L_WIRE_51)                                                               ', 'Charge(L_WIRE_52)                                                               ', 'Charge(L_WIRE_53)                                                               ', 'Charge(L_WIRE_54)                                                               ', 'Charge(L_WIRE_55)                                                               ', 'Charge(L_WIRE_56)                                                               ', 'Charge(L_WIRE_57)                                                               ', 'Charge(L_WIRE_58)                                                               ', 'Charge(L_WIRE_59)                                                               ', 'Charge(L_WIRE_60)                                                               ', 'Charge(L_WIRE_61)                                                               ', 'Charge(L_WIRE_62)                                                               ', 'Charge(L_WIRE_63)                                                               ', 'Charge(L_WIRE_64)                                                               ', 'Charge(L_WIRE_65)                                                               ', 'Charge(L_WIRE_66)                                                               ', 'Charge(L_WIRE_67)                                                               ', 'Charge(L_WIRE_68)                                                               '])
     Scenario['SCENARIO_1'].deleteAllResults()
######################################


ComputePhysic[ALL].exportExcel(xlsFile='covh',
            mode='add')

saveProject()

#! Tue Mar 22 12:44:32 IRDT 2016 loadProject('D:/RandomWoundMTLmodeling/SimulFlux/OVERHANG-ELECTROSTATIC/OVHCAP.FLU')

deleteMesh()

ComputePhysic[ALL].delete()
RegionLine['WIRE_68'].electroStatic2D=ElectroStatic2DLinePerfectConductorImposedPotential(value='0')


meshDomain()

result = PointCoordinates[759].computePointDistance(point=[Point[802]],
                     coordSys=CoordSys['GEOM_CORRECT_1'])

deleteMesh()

startMacroTransaction()
GeomMeshOptions[1].geomRelativeEpsilon=1.0E-6

GeomMeshOptions[1].meshRelativeEpsilon=1.0E-7

endMacroTransaction()

checkGeometry()

openSketcher2dContext()

checkGeometry()

closeSketcher2dContext()

buildFaces()

deleteMesh()

meshDomain()

Scenario['SCENARIO_1'].solve(projectName='D:/RandomWoundMTLmodeling/SimulFlux/OVERHANG-ELECTROSTATIC/OVHCAP.FLU')

deleteMesh()

