#! Flux2D 12.0
#! Mon Mar 21 01:04:21 IRDT 2016 loadProject('D:/SimulFlux/OVERHANG-ELECTROSTATIC/OVHCAP.FLU')

AidedMesh[1].aidedMeshState=AidedMeshActivated(meshPoint=MeshPointAssigned(type=MeshPointDynamic()),
                                               meshDeviation=MeshDeviationAssignedExcludeIB(type=MeshDeviationExcludeIBRelative(value=0.5)),
                                               meshRelaxation=MeshRelaxation(lineMeshRelaxation=LineMeshRelaxationAssigned(type=LineMeshRelaxationMedium()),
                                                                             faceMeshRelaxation=FaceMeshRelaxationAssigned(type=FaceMeshRelaxationMedium())))


deleteMesh()

MeshPoint['LARGE','MEDIUM','SMALL'].delete()
saveProject()

checkMesh()

meshDomain()

checkGeometry()

result = checkPhysic()

#! Flux2D 12.0
for count in range(1,10):
     RegionLine['WIRE_0'+str(count)].electroStatic2D=ElectroStatic2DLinePerfectConductorImposedPotential(value='0')

for count in range(10,69):
     RegionLine['WIRE_'+str(count)].electroStatic2D=ElectroStatic2DLinePerfectConductorImposedPotential(value='0')

######################################
for count in range(1,69):
     
     if count < 10:
          curwir='WIRE_0'+str(count)
     else:
          curwir='WIRE_'+str(count)
     
          
     if (count-1) < 10:
          prvwir='WIRE_0'+str(count-1)
     else:
          prvwir='WIRE_'+str(count-1)
     
          
          
     if count != 1:
          RegionLine[prvwir].electroStatic2D=ElectroStatic2DLinePerfectConductorImposedPotential(value='0')
     
     RegionLine[curwir].electroStatic2D=ElectroStatic2DLinePerfectConductorImposedPotential(value='1')
     Scenario['SCENARIO_1'].solve(projectName='D:\SimulFlux\OVERHANG-ELECTROSTATIC\OVHCAP.FLU')
     ComputePhysicTransient['ComputePhysic'].storageName='ComputePhysic_'+curwir
     lastInstance = ComputePhysic(name='ComputePhysic_'+curwir,formula=['Charge(L_WIRE_01)                                                               ', 'Charge(L_WIRE_02)                                                               ', 'Charge(L_WIRE_03)                                                               ', 'Charge(L_WIRE_04)                                                               ', 'Charge(L_WIRE_05)                                                               ', 'Charge(L_WIRE_06)                                                               ', 'Charge(L_WIRE_07)                                                               ', 'Charge(L_WIRE_08)                                                               ', 'Charge(L_WIRE_09)                                                               ', 'Charge(L_WIRE_10)                                                               ', 'Charge(L_WIRE_11)                                                               ', 'Charge(L_WIRE_12)                                                               ', 'Charge(L_WIRE_13)                                                               ', 'Charge(L_WIRE_14)                                                               ', 'Charge(L_WIRE_15)                                                               ', 'Charge(L_WIRE_16)                                                               ', 'Charge(L_WIRE_17)                                                               ', 'Charge(L_WIRE_18)                                                               ', 'Charge(L_WIRE_19)                                                               ', 'Charge(L_WIRE_20)                                                               ', 'Charge(L_WIRE_21)                                                               ', 'Charge(L_WIRE_22)                                                               ', 'Charge(L_WIRE_23)                                                               ', 'Charge(L_WIRE_24)                                                               ', 'Charge(L_WIRE_25)                                                               ', 'Charge(L_WIRE_26)                                                               ', 'Charge(L_WIRE_27)                                                               ', 'Charge(L_WIRE_28)                                                               ', 'Charge(L_WIRE_29)                                                               ', 'Charge(L_WIRE_30)                                                               ', 'Charge(L_WIRE_31)                                                               ', 'Charge(L_WIRE_32)                                                               ', 'Charge(L_WIRE_33)                                                               ', 'Charge(L_WIRE_34)                                                               ', 'Charge(L_WIRE_35)                                                               ', 'Charge(L_WIRE_36)                                                               ', 'Charge(L_WIRE_37)                                                               ', 'Charge(L_WIRE_38)                                                               ', 'Charge(L_WIRE_39)                                                               ', 'Charge(L_WIRE_40)                                                               ', 'Charge(L_WIRE_41)                                                               ', 'Charge(L_WIRE_42)                                                               ', 'Charge(L_WIRE_43)                                                               ', 'Charge(L_WIRE_44)                                                               ', 'Charge(L_WIRE_45)                                                               ', 'Charge(L_WIRE_46)                                                               ', 'Charge(L_WIRE_47)                                                               ', 'Charge(L_WIRE_48)                                                               ', 'Charge(L_WIRE_49)                                                               ', 'Charge(L_WIRE_50)                                                               ', 'Charge(L_WIRE_51)                                                               ', 'Charge(L_WIRE_52)                                                               ', 'Charge(L_WIRE_53)                                                               ', 'Charge(L_WIRE_54)                                                               ', 'Charge(L_WIRE_55)                                                               ', 'Charge(L_WIRE_56)                                                               ', 'Charge(L_WIRE_57)                                                               ', 'Charge(L_WIRE_58)                                                               ', 'Charge(L_WIRE_59)                                                               ', 'Charge(L_WIRE_60)                                                               ', 'Charge(L_WIRE_61)                                                               ', 'Charge(L_WIRE_62)                                                               ', 'Charge(L_WIRE_63)                                                               ', 'Charge(L_WIRE_64)                                                               ', 'Charge(L_WIRE_65)                                                               ', 'Charge(L_WIRE_66)                                                               ', 'Charge(L_WIRE_67)                                                               ', 'Charge(L_WIRE_68)                                                               '])
     Scenario['SCENARIO_1'].deleteAllResults()
######################################


ComputePhysic[ALL].exportExcel(xlsFile='covh',
            mode='add')

saveProject()

#! Tue Mar 22 13:04:18 IRDT 2016 loadProject('D:/RandomWoundMTLmodeling/SimulFlux/OVERHANG-ELECTROSTATIC/OVHCAP.FLU')

deleteMesh()

ComputePhysic[ALL].delete()
startMacroTransaction()
GeomMeshOptions[1].geomRelativeEpsilon=1.0E-6

GeomMeshOptions[1].meshRelativeEpsilon=1.0E-7

endMacroTransaction()

checkGeometry()

meshDomain()

RegionLine['WIRE_68'].electroStatic2D=ElectroStatic2DLinePerfectConductorImposedPotential(value='0')


saveProject()

result = checkPhysic()

Scenario['SCENARIO_1'].solve(projectName='D:/RandomWoundMTLmodeling/SimulFlux/OVERHANG-ELECTROSTATIC/OVHCAP.FLU')

displayIsovalues()

DeleteAllResults(deletePostprocessingResults='yes')

saveProject()

#! Flux2D 12.0
for count in range(1,10):
     RegionLine['WIRE_0'+str(count)].electroStatic2D=ElectroStatic2DLinePerfectConductorImposedPotential(value='0')

for count in range(10,69):
     RegionLine['WIRE_'+str(count)].electroStatic2D=ElectroStatic2DLinePerfectConductorImposedPotential(value='0')

######################################
for count in range(1,69):
     
     if count < 10:
          curwir='WIRE_0'+str(count)
     else:
          curwir='WIRE_'+str(count)
     
          
     if (count-1) < 10:
          prvwir='WIRE_0'+str(count-1)
     else:
          prvwir='WIRE_'+str(count-1)
     
          
          
     if count != 1:
          RegionLine[prvwir].electroStatic2D=ElectroStatic2DLinePerfectConductorImposedPotential(value='0')
     
     RegionLine[curwir].electroStatic2D=ElectroStatic2DLinePerfectConductorImposedPotential(value='1')
     Scenario['SCENARIO_1'].solve(projectName='D:\RandomWoundMTLmodeling\SimulFlux\OVERHANG-ELECTROSTATIC\OVHCAP.FLU')
     ComputePhysicTransient['ComputePhysic'].storageName='ComputePhysic_'+curwir
     lastInstance = ComputePhysic(name='ComputePhysic_'+curwir,formula=['Charge(L_WIRE_01)                                                               ', 'Charge(L_WIRE_02)                                                               ', 'Charge(L_WIRE_03)                                                               ', 'Charge(L_WIRE_04)                                                               ', 'Charge(L_WIRE_05)                                                               ', 'Charge(L_WIRE_06)                                                               ', 'Charge(L_WIRE_07)                                                               ', 'Charge(L_WIRE_08)                                                               ', 'Charge(L_WIRE_09)                                                               ', 'Charge(L_WIRE_10)                                                               ', 'Charge(L_WIRE_11)                                                               ', 'Charge(L_WIRE_12)                                                               ', 'Charge(L_WIRE_13)                                                               ', 'Charge(L_WIRE_14)                                                               ', 'Charge(L_WIRE_15)                                                               ', 'Charge(L_WIRE_16)                                                               ', 'Charge(L_WIRE_17)                                                               ', 'Charge(L_WIRE_18)                                                               ', 'Charge(L_WIRE_19)                                                               ', 'Charge(L_WIRE_20)                                                               ', 'Charge(L_WIRE_21)                                                               ', 'Charge(L_WIRE_22)                                                               ', 'Charge(L_WIRE_23)                                                               ', 'Charge(L_WIRE_24)                                                               ', 'Charge(L_WIRE_25)                                                               ', 'Charge(L_WIRE_26)                                                               ', 'Charge(L_WIRE_27)                                                               ', 'Charge(L_WIRE_28)                                                               ', 'Charge(L_WIRE_29)                                                               ', 'Charge(L_WIRE_30)                                                               ', 'Charge(L_WIRE_31)                                                               ', 'Charge(L_WIRE_32)                                                               ', 'Charge(L_WIRE_33)                                                               ', 'Charge(L_WIRE_34)                                                               ', 'Charge(L_WIRE_35)                                                               ', 'Charge(L_WIRE_36)                                                               ', 'Charge(L_WIRE_37)                                                               ', 'Charge(L_WIRE_38)                                                               ', 'Charge(L_WIRE_39)                                                               ', 'Charge(L_WIRE_40)                                                               ', 'Charge(L_WIRE_41)                                                               ', 'Charge(L_WIRE_42)                                                               ', 'Charge(L_WIRE_43)                                                               ', 'Charge(L_WIRE_44)                                                               ', 'Charge(L_WIRE_45)                                                               ', 'Charge(L_WIRE_46)                                                               ', 'Charge(L_WIRE_47)                                                               ', 'Charge(L_WIRE_48)                                                               ', 'Charge(L_WIRE_49)                                                               ', 'Charge(L_WIRE_50)                                                               ', 'Charge(L_WIRE_51)                                                               ', 'Charge(L_WIRE_52)                                                               ', 'Charge(L_WIRE_53)                                                               ', 'Charge(L_WIRE_54)                                                               ', 'Charge(L_WIRE_55)                                                               ', 'Charge(L_WIRE_56)                                                               ', 'Charge(L_WIRE_57)                                                               ', 'Charge(L_WIRE_58)                                                               ', 'Charge(L_WIRE_59)                                                               ', 'Charge(L_WIRE_60)                                                               ', 'Charge(L_WIRE_61)                                                               ', 'Charge(L_WIRE_62)                                                               ', 'Charge(L_WIRE_63)                                                               ', 'Charge(L_WIRE_64)                                                               ', 'Charge(L_WIRE_65)                                                               ', 'Charge(L_WIRE_66)                                                               ', 'Charge(L_WIRE_67)                                                               ', 'Charge(L_WIRE_68)                                                               '])
     Scenario['SCENARIO_1'].deleteAllResults()
######################################


RegionLine['WIRE_68'].electroStatic2D=ElectroStatic2DLinePerfectConductorImposedPotential(value='0')


saveProject()

ComputePhysic[ALL].exportExcel(xlsFile='covh',
            mode='replace')

saveProject()

#! Mon Feb 13 21:09:41 IRST 2017 loadProject('D:/TLM-MODEL/L-cal-7KHz/OVERHANG-C/OVHCAP.FLU')

FaceAutomatic[3,2].assignRegion(region=RegionFace['PLATE'])

FaceAutomatic[183,195,182,184].assignRegion(region=RegionFace['SHAFT'])

FaceAutomatic[13].assignRegion(region=RegionFace['SHAFT'])

FaceAutomatic[7,12].assignRegion(region=RegionFace['SHAFT'])

FaceAutomatic[185,180].assignRegion(region=RegionFace['SHAFT'])

FaceAutomatic[17,16,15,6].assignRegion(region=RegionFace['SHAFT'])

FaceAutomatic[198,189,196,199,197,25].assignRegion(region=RegionFace['SHAFT'])

FaceAutomatic[2,3,191,190,1,181].assignRegion(region=RegionFace['STATOR'])

RegionFace['PLATE'].delete()
RegionFace['RING'].delete()
RegionFace['ROTOR'].delete()
RegionFace['SCREW'].delete()
RegionFace['SCREW'].deleteForce()
RegionFace['SHEILD'].delete()
RegionFace['STAND'].delete()
saveProject()

RegionFace['BEARING'].color=Color['Magenta']


assignRegionToFaces(face=[Face[10]],
                    region=RegionFace['STATOR'])

FaceAutomatic[10].assignRegion(region=RegionFace['SHAFT'])

result = checkPhysic()

Scenario['SCENARIO_1'].solve(projectName='D:/TLM-MODEL/L-cal-7KHz/OVERHANG-C/OVHCAP.FLU')

displayIsolines()

Scenario['SCENARIO_1'].delete()
RegionLine['WIRE_01'].electroStatic2D=ElectroStatic2DLinePerfectConductorImposedPotential(value='1')


Scenario(name='ReferenceValues')

Scenario['ReferenceValues'].adaptive = InactivatedAdaptive()

Scenario['ReferenceValues'].solve(projectName='D:/TLM-MODEL/L-cal-7KHz/OVERHANG-C/OVHCAP.FLU')

displayIsolines()

DeleteAllResults(deletePostprocessingResults='yes')

RegionLine['WIRE_01'].electroStatic2D=ElectroStatic2DLinePerfectConductorImposedPotential(value='0')


Scenario['REFERENCEVALUES'].solve(projectName='D:/TLM-MODEL/L-cal-7KHz/OVERHANG-C/OVHCAP.FLU')

displayIsolines()

DeleteAllResults(deletePostprocessingResults='yes')

RegionFace['STATOR'].electroStatic2D=ElectroStatic2DFacePerfectConductorImposedPotential(value='1')


RegionFace['BEARING'].electroStatic2D=ElectroStatic2DFacePerfectConductorImposedPotential(value='0')


RegionFace['SHAFT'].electroStatic2D=ElectroStatic2DFacePerfectConductorImposedPotential(value='0')


RegionFace['STATOR'].electroStatic2D=ElectroStatic2DFacePerfectConductorImposedPotential(value='0')


Scenario['REFERENCEVALUES'].solve(projectName='D:/TLM-MODEL/L-cal-7KHz/OVERHANG-C/OVHCAP.FLU')

displayIsolines()

DeleteAllResults(deletePostprocessingResults='yes')

startMacroTransaction()
Scenario['REFERENCEVALUES'].name='SCENARIO_1'
endMacroTransaction()

result = checkPhysic()

result = checkPhysic()

#! Flux2D 12.0
for count in range(1,10):
     RegionLine['WIRE_0'+str(count)].electroStatic2D=ElectroStatic2DLinePerfectConductorImposedPotential(value='0')

for count in range(10,69):
     RegionLine['WIRE_'+str(count)].electroStatic2D=ElectroStatic2DLinePerfectConductorImposedPotential(value='0')

######################################
for count in range(1,69):
     
     if count < 10:
          curwir='WIRE_0'+str(count)
     else:
          curwir='WIRE_'+str(count)
     
          
     if (count-1) < 10:
          prvwir='WIRE_0'+str(count-1)
     else:
          prvwir='WIRE_'+str(count-1)
     
          
          
     if count != 1:
          RegionLine[prvwir].electroStatic2D=ElectroStatic2DLinePerfectConductorImposedPotential(value='0')
     
     RegionLine[curwir].electroStatic2D=ElectroStatic2DLinePerfectConductorImposedPotential(value='1')
     Scenario['SCENARIO_1'].solve(projectName='D:\TLM-MODEL\L-cal-7KHz\OVERHANG-C\OVHCAP.FLU')
     ComputePhysicTransient['ComputePhysic'].storageName='ComputePhysic_'+curwir
     lastInstance = ComputePhysic(name='ComputePhysic_'+curwir,formula=['Charge(S_BEARING)','Charge(S_SHAFT)','Charge(S_STATOR)','Charge(L_WIRE_01)                                                               ', 'Charge(L_WIRE_02)                                                               ', 'Charge(L_WIRE_03)                                                               ', 'Charge(L_WIRE_04)                                                               ', 'Charge(L_WIRE_05)                                                               ', 'Charge(L_WIRE_06)                                                               ', 'Charge(L_WIRE_07)                                                               ', 'Charge(L_WIRE_08)                                                               ', 'Charge(L_WIRE_09)                                                               ', 'Charge(L_WIRE_10)                                                               ', 'Charge(L_WIRE_11)                                                               ', 'Charge(L_WIRE_12)                                                               ', 'Charge(L_WIRE_13)                                                               ', 'Charge(L_WIRE_14)                                                               ', 'Charge(L_WIRE_15)                                                               ', 'Charge(L_WIRE_16)                                                               ', 'Charge(L_WIRE_17)                                                               ', 'Charge(L_WIRE_18)                                                               ', 'Charge(L_WIRE_19)                                                               ', 'Charge(L_WIRE_20)                                                               ', 'Charge(L_WIRE_21)                                                               ', 'Charge(L_WIRE_22)                                                               ', 'Charge(L_WIRE_23)                                                               ', 'Charge(L_WIRE_24)                                                               ', 'Charge(L_WIRE_25)                                                               ', 'Charge(L_WIRE_26)                                                               ', 'Charge(L_WIRE_27)                                                               ', 'Charge(L_WIRE_28)                                                               ', 'Charge(L_WIRE_29)                                                               ', 'Charge(L_WIRE_30)                                                               ', 'Charge(L_WIRE_31)                                                               ', 'Charge(L_WIRE_32)                                                               ', 'Charge(L_WIRE_33)                                                               ', 'Charge(L_WIRE_34)                                                               ', 'Charge(L_WIRE_35)                                                               ', 'Charge(L_WIRE_36)                                                               ', 'Charge(L_WIRE_37)                                                               ', 'Charge(L_WIRE_38)                                                               ', 'Charge(L_WIRE_39)                                                               ', 'Charge(L_WIRE_40)                                                               ', 'Charge(L_WIRE_41)                                                               ', 'Charge(L_WIRE_42)                                                               ', 'Charge(L_WIRE_43)                                                               ', 'Charge(L_WIRE_44)                                                               ', 'Charge(L_WIRE_45)                                                               ', 'Charge(L_WIRE_46)                                                               ', 'Charge(L_WIRE_47)                                                               ', 'Charge(L_WIRE_48)                                                               ', 'Charge(L_WIRE_49)                                                               ', 'Charge(L_WIRE_50)                                                               ', 'Charge(L_WIRE_51)                                                               ', 'Charge(L_WIRE_52)                                                               ', 'Charge(L_WIRE_53)                                                               ', 'Charge(L_WIRE_54)                                                               ', 'Charge(L_WIRE_55)                                                               ', 'Charge(L_WIRE_56)                                                               ', 'Charge(L_WIRE_57)                                                               ', 'Charge(L_WIRE_58)                                                               ', 'Charge(L_WIRE_59)                                                               ', 'Charge(L_WIRE_60)                                                               ', 'Charge(L_WIRE_61)                                                               ', 'Charge(L_WIRE_62)                                                               ', 'Charge(L_WIRE_63)                                                               ', 'Charge(L_WIRE_64)                                                               ', 'Charge(L_WIRE_65)                                                               ', 'Charge(L_WIRE_66)                                                               ', 'Charge(L_WIRE_67)                                                               ', 'Charge(L_WIRE_68)                                                               '])
     Scenario['SCENARIO_1'].deleteAllResults()
######################################
RegionLine['WIRE_68'].electroStatic2D=ElectroStatic2DLinePerfectConductorImposedPotential(value='0')

RegionFace['STATOR'].electroStatic2D=ElectroStatic2DFacePerfectConductorImposedPotential(value='1')
Scenario['SCENARIO_1'].solve(projectName='D:\TLM-MODEL\L-cal-7KHz\OVERHANG-C\OVHCAP.FLU')
ComputePhysicTransient['ComputePhysic'].storageName='ComputePhysic_STATOR'
lastInstance = ComputePhysic(name='ComputePhysic_STATOR',formula=['Charge(S_BEARING)','Charge(S_SHAFT)','Charge(S_STATOR)','Charge(L_WIRE_01)                                                               ', 'Charge(L_WIRE_02)                                                               ', 'Charge(L_WIRE_03)                                                               ', 'Charge(L_WIRE_04)                                                               ', 'Charge(L_WIRE_05)                                                               ', 'Charge(L_WIRE_06)                                                               ', 'Charge(L_WIRE_07)                                                               ', 'Charge(L_WIRE_08)                                                               ', 'Charge(L_WIRE_09)                                                               ', 'Charge(L_WIRE_10)                                                               ', 'Charge(L_WIRE_11)                                                               ', 'Charge(L_WIRE_12)                                                               ', 'Charge(L_WIRE_13)                                                               ', 'Charge(L_WIRE_14)                                                               ', 'Charge(L_WIRE_15)                                                               ', 'Charge(L_WIRE_16)                                                               ', 'Charge(L_WIRE_17)                                                               ', 'Charge(L_WIRE_18)                                                               ', 'Charge(L_WIRE_19)                                                               ', 'Charge(L_WIRE_20)                                                               ', 'Charge(L_WIRE_21)                                                               ', 'Charge(L_WIRE_22)                                                               ', 'Charge(L_WIRE_23)                                                               ', 'Charge(L_WIRE_24)                                                               ', 'Charge(L_WIRE_25)                                                               ', 'Charge(L_WIRE_26)                                                               ', 'Charge(L_WIRE_27)                                                               ', 'Charge(L_WIRE_28)                                                               ', 'Charge(L_WIRE_29)                                                               ', 'Charge(L_WIRE_30)                                                               ', 'Charge(L_WIRE_31)                                                               ', 'Charge(L_WIRE_32)                                                               ', 'Charge(L_WIRE_33)                                                               ', 'Charge(L_WIRE_34)                                                               ', 'Charge(L_WIRE_35)                                                               ', 'Charge(L_WIRE_36)                                                               ', 'Charge(L_WIRE_37)                                                               ', 'Charge(L_WIRE_38)                                                               ', 'Charge(L_WIRE_39)                                                               ', 'Charge(L_WIRE_40)                                                               ', 'Charge(L_WIRE_41)                                                               ', 'Charge(L_WIRE_42)                                                               ', 'Charge(L_WIRE_43)                                                               ', 'Charge(L_WIRE_44)                                                               ', 'Charge(L_WIRE_45)                                                               ', 'Charge(L_WIRE_46)                                                               ', 'Charge(L_WIRE_47)                                                               ', 'Charge(L_WIRE_48)                                                               ', 'Charge(L_WIRE_49)                                                               ', 'Charge(L_WIRE_50)                                                               ', 'Charge(L_WIRE_51)                                                               ', 'Charge(L_WIRE_52)                                                               ', 'Charge(L_WIRE_53)                                                               ', 'Charge(L_WIRE_54)                                                               ', 'Charge(L_WIRE_55)                                                               ', 'Charge(L_WIRE_56)                                                               ', 'Charge(L_WIRE_57)                                                               ', 'Charge(L_WIRE_58)                                                               ', 'Charge(L_WIRE_59)                                                               ', 'Charge(L_WIRE_60)                                                               ', 'Charge(L_WIRE_61)                                                               ', 'Charge(L_WIRE_62)                                                               ', 'Charge(L_WIRE_63)                                                               ', 'Charge(L_WIRE_64)                                                               ', 'Charge(L_WIRE_65)                                                               ', 'Charge(L_WIRE_66)                                                               ', 'Charge(L_WIRE_67)                                                               ', 'Charge(L_WIRE_68)                                                               '])
Scenario['SCENARIO_1'].deleteAllResults()
######################################
RegionFace['STATOR'].electroStatic2D=ElectroStatic2DFacePerfectConductorImposedPotential(value='0')

RegionFace['SHAFT'].electroStatic2D=ElectroStatic2DFacePerfectConductorImposedPotential(value='1')
Scenario['SCENARIO_1'].solve(projectName='D:\TLM-MODEL\L-cal-7KHz\OVERHANG-C\OVHCAP.FLU')
ComputePhysicTransient['ComputePhysic'].storageName='ComputePhysic_SHAFT'
lastInstance = ComputePhysic(name='ComputePhysic_SHAFT',formula=['Charge(S_BEARING)','Charge(S_SHAFT)','Charge(S_STATOR)','Charge(L_WIRE_01)                                                               ', 'Charge(L_WIRE_02)                                                               ', 'Charge(L_WIRE_03)                                                               ', 'Charge(L_WIRE_04)                                                               ', 'Charge(L_WIRE_05)                                                               ', 'Charge(L_WIRE_06)                                                               ', 'Charge(L_WIRE_07)                                                               ', 'Charge(L_WIRE_08)                                                               ', 'Charge(L_WIRE_09)                                                               ', 'Charge(L_WIRE_10)                                                               ', 'Charge(L_WIRE_11)                                                               ', 'Charge(L_WIRE_12)                                                               ', 'Charge(L_WIRE_13)                                                               ', 'Charge(L_WIRE_14)                                                               ', 'Charge(L_WIRE_15)                                                               ', 'Charge(L_WIRE_16)                                                               ', 'Charge(L_WIRE_17)                                                               ', 'Charge(L_WIRE_18)                                                               ', 'Charge(L_WIRE_19)                                                               ', 'Charge(L_WIRE_20)                                                               ', 'Charge(L_WIRE_21)                                                               ', 'Charge(L_WIRE_22)                                                               ', 'Charge(L_WIRE_23)                                                               ', 'Charge(L_WIRE_24)                                                               ', 'Charge(L_WIRE_25)                                                               ', 'Charge(L_WIRE_26)                                                               ', 'Charge(L_WIRE_27)                                                               ', 'Charge(L_WIRE_28)                                                               ', 'Charge(L_WIRE_29)                                                               ', 'Charge(L_WIRE_30)                                                               ', 'Charge(L_WIRE_31)                                                               ', 'Charge(L_WIRE_32)                                                               ', 'Charge(L_WIRE_33)                                                               ', 'Charge(L_WIRE_34)                                                               ', 'Charge(L_WIRE_35)                                                               ', 'Charge(L_WIRE_36)                                                               ', 'Charge(L_WIRE_37)                                                               ', 'Charge(L_WIRE_38)                                                               ', 'Charge(L_WIRE_39)                                                               ', 'Charge(L_WIRE_40)                                                               ', 'Charge(L_WIRE_41)                                                               ', 'Charge(L_WIRE_42)                                                               ', 'Charge(L_WIRE_43)                                                               ', 'Charge(L_WIRE_44)                                                               ', 'Charge(L_WIRE_45)                                                               ', 'Charge(L_WIRE_46)                                                               ', 'Charge(L_WIRE_47)                                                               ', 'Charge(L_WIRE_48)                                                               ', 'Charge(L_WIRE_49)                                                               ', 'Charge(L_WIRE_50)                                                               ', 'Charge(L_WIRE_51)                                                               ', 'Charge(L_WIRE_52)                                                               ', 'Charge(L_WIRE_53)                                                               ', 'Charge(L_WIRE_54)                                                               ', 'Charge(L_WIRE_55)                                                               ', 'Charge(L_WIRE_56)                                                               ', 'Charge(L_WIRE_57)                                                               ', 'Charge(L_WIRE_58)                                                               ', 'Charge(L_WIRE_59)                                                               ', 'Charge(L_WIRE_60)                                                               ', 'Charge(L_WIRE_61)                                                               ', 'Charge(L_WIRE_62)                                                               ', 'Charge(L_WIRE_63)                                                               ', 'Charge(L_WIRE_64)                                                               ', 'Charge(L_WIRE_65)                                                               ', 'Charge(L_WIRE_66)                                                               ', 'Charge(L_WIRE_67)                                                               ', 'Charge(L_WIRE_68)                                                               '])
Scenario['SCENARIO_1'].deleteAllResults()
######################################
RegionFace['SHAFT'].electroStatic2D=ElectroStatic2DFacePerfectConductorImposedPotential(value='0')

RegionFace['BEARING'].electroStatic2D=ElectroStatic2DFacePerfectConductorImposedPotential(value='1')
Scenario['SCENARIO_1'].solve(projectName='D:\TLM-MODEL\L-cal-7KHz\OVERHANG-C\OVHCAP.FLU')
ComputePhysicTransient['ComputePhysic'].storageName='ComputePhysic_BEARING'
lastInstance = ComputePhysic(name='ComputePhysic_BEARING',formula=['Charge(S_BEARING)','Charge(S_SHAFT)','Charge(S_STATOR)','Charge(L_WIRE_01)                                                               ', 'Charge(L_WIRE_02)                                                               ', 'Charge(L_WIRE_03)                                                               ', 'Charge(L_WIRE_04)                                                               ', 'Charge(L_WIRE_05)                                                               ', 'Charge(L_WIRE_06)                                                               ', 'Charge(L_WIRE_07)                                                               ', 'Charge(L_WIRE_08)                                                               ', 'Charge(L_WIRE_09)                                                               ', 'Charge(L_WIRE_10)                                                               ', 'Charge(L_WIRE_11)                                                               ', 'Charge(L_WIRE_12)                                                               ', 'Charge(L_WIRE_13)                                                               ', 'Charge(L_WIRE_14)                                                               ', 'Charge(L_WIRE_15)                                                               ', 'Charge(L_WIRE_16)                                                               ', 'Charge(L_WIRE_17)                                                               ', 'Charge(L_WIRE_18)                                                               ', 'Charge(L_WIRE_19)                                                               ', 'Charge(L_WIRE_20)                                                               ', 'Charge(L_WIRE_21)                                                               ', 'Charge(L_WIRE_22)                                                               ', 'Charge(L_WIRE_23)                                                               ', 'Charge(L_WIRE_24)                                                               ', 'Charge(L_WIRE_25)                                                               ', 'Charge(L_WIRE_26)                                                               ', 'Charge(L_WIRE_27)                                                               ', 'Charge(L_WIRE_28)                                                               ', 'Charge(L_WIRE_29)                                                               ', 'Charge(L_WIRE_30)                                                               ', 'Charge(L_WIRE_31)                                                               ', 'Charge(L_WIRE_32)                                                               ', 'Charge(L_WIRE_33)                                                               ', 'Charge(L_WIRE_34)                                                               ', 'Charge(L_WIRE_35)                                                               ', 'Charge(L_WIRE_36)                                                               ', 'Charge(L_WIRE_37)                                                               ', 'Charge(L_WIRE_38)                                                               ', 'Charge(L_WIRE_39)                                                               ', 'Charge(L_WIRE_40)                                                               ', 'Charge(L_WIRE_41)                                                               ', 'Charge(L_WIRE_42)                                                               ', 'Charge(L_WIRE_43)                                                               ', 'Charge(L_WIRE_44)                                                               ', 'Charge(L_WIRE_45)                                                               ', 'Charge(L_WIRE_46)                                                               ', 'Charge(L_WIRE_47)                                                               ', 'Charge(L_WIRE_48)                                                               ', 'Charge(L_WIRE_49)                                                               ', 'Charge(L_WIRE_50)                                                               ', 'Charge(L_WIRE_51)                                                               ', 'Charge(L_WIRE_52)                                                               ', 'Charge(L_WIRE_53)                                                               ', 'Charge(L_WIRE_54)                                                               ', 'Charge(L_WIRE_55)                                                               ', 'Charge(L_WIRE_56)                                                               ', 'Charge(L_WIRE_57)                                                               ', 'Charge(L_WIRE_58)                                                               ', 'Charge(L_WIRE_59)                                                               ', 'Charge(L_WIRE_60)                                                               ', 'Charge(L_WIRE_61)                                                               ', 'Charge(L_WIRE_62)                                                               ', 'Charge(L_WIRE_63)                                                               ', 'Charge(L_WIRE_64)                                                               ', 'Charge(L_WIRE_65)                                                               ', 'Charge(L_WIRE_66)                                                               ', 'Charge(L_WIRE_67)                                                               ', 'Charge(L_WIRE_68)                                                               '])
Scenario['SCENARIO_1'].deleteAllResults()
######################################
RegionFace['BEARING'].electroStatic2D=ElectroStatic2DFacePerfectConductorImposedPotential(value='0')

ComputePhysic[ALL].exportExcel(xlsFile='COFLUX',
            mode='replace')

saveProject()

